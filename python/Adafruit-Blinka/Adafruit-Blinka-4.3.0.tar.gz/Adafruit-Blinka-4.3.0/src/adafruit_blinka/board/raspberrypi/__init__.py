"""Boards definition from Raspberry Pi"""
