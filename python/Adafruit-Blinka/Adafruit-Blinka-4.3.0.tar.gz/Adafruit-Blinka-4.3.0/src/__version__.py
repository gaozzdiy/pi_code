VERSION = (1, 0, 0)

__version__ = '.'.join(map(str, VERSION))
